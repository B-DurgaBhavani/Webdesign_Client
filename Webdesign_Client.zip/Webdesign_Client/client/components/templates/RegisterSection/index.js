import RegisterSection from './RegisterSection';

export default RegisterSection;
