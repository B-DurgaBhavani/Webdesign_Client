import LostSection from './LostSection';

export default LostSection;
