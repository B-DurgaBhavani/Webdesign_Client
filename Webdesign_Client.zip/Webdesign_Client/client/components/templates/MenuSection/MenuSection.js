import React from 'react';

import Menu from '../../organisms/Menu';

export default function MenuSection() {
  return (
   

    <div className="profile-settings">
        {console.log("Step 1")}
      <Menu />
    </div>
  );
}
