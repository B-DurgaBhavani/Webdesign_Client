import React from 'react';

import GeneralProfile from '_organisms/GeneralProfile';

export default function ProfileSettings() {
  return (
   

    <div className="profile-settings">
        {console.log("Step 1")}
      <GeneralProfile />
    </div>
  );
}
