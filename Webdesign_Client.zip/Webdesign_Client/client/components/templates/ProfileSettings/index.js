import ProfileSettings from './ProfileSettings';

export default ProfileSettings;
