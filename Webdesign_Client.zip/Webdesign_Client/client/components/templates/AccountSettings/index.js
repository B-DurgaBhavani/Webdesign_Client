import AccountSettings from './AccountSettings';

export default AccountSettings;
