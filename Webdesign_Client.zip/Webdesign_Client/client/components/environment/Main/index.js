import { withRouter } from 'react-router-dom';

import Main from './Main';

export default withRouter(Main);
