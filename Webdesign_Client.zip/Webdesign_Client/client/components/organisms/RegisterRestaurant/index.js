import RegisterRestaurant from './RegisterRestaurant';

export default RegisterRestaurant;
