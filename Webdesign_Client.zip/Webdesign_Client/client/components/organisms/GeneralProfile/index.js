import GeneralProfile from './GeneralProfile';

export default GeneralProfile;
