import ConfirmDeleteTodo from './ConfirmDeleteTodo';

export default ConfirmDeleteTodo;
