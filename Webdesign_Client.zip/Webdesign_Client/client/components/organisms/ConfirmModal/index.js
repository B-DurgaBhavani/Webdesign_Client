import ConfirmModal from './ConfirmModal';

export default ConfirmModal;
