import R from 'ramda';
import { connect } from 'react-redux';
import Footer from './Footer';

const mapStateToProps = R.pick([]);

export default connect(mapStateToProps)(Footer);
