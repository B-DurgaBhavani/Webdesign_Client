import SettingsMenu from './SettingsMenu';

export default SettingsMenu;
