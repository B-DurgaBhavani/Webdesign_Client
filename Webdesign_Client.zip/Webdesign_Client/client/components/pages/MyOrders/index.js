import MyOrders from './MyOrders';

export default MyOrders;
