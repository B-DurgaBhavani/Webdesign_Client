import  MenuListPage from './MenuListPage';

export default MenuListPage;