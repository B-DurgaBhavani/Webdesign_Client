import RestaurantOrders from './RestaurantOrders';

export default RestaurantOrders;
