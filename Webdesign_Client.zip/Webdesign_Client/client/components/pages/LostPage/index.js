import LostPage from './LostPage';

export default LostPage;
