import React from 'react';
import LostSection from '_templates/LostSection';

export default function LostPage() {
  return (
    <div className="lost-page page">
      <LostSection />
    </div>
  );
}
