import  RegisterRestaurantPage from './RegisterRestaurantPage';

export default RegisterRestaurantPage;