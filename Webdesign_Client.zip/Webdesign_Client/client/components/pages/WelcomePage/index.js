import WelcomePage from './WelcomePage';

export default WelcomePage;
