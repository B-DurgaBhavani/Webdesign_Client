jest client --config=./config/jest.config.js --verbose
