jest client --config=./config/jest.config.js --watch
